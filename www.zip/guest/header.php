<?php
require '../db.php';
if(!isset($_GET["key"])){
    header($_SERVER['SERVER_PROTOCOL'] . ' 404 Not Found');
    exit;
}
$key = checkStr($_GET["key"]);
$guest = R::findOne('guest', 'link_key = ?', [$key]);
if($guest == NULL){
    header($_SERVER['SERVER_PROTOCOL'] . ' 404 Not Found');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>
        Guest statistics - Mars
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />



</head>


