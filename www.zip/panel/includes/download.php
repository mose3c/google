<?php
require "../../db.php";
$zip = new ZipArchive;
$res = $zip->open('test.zip', ZipArchive::OVERWRITE|ZipArchive::CREATE);
if ($res === TRUE) {
    $archives = scandir('../'.$GLOBALS['logspath']);
    foreach ($archives as $archive){
        if(strpos($archive, ".zip")!== false){
            $zip->addFile('../'.$GLOBALS['logspath'].'/'.$archive, $archive);
        }
    }
    header("location: test.zip");
    //unlink("test.zip");
    echo 'готово';
} else {
    echo 'ошибка';
}
$zip->close();

echo "good";

?>