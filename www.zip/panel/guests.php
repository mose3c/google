<?php
include("./header.php");
?>


<!-- Page Content-->
<div class="page-content">
    <div class="container">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="row">
                        <div class="col">
                            <h4 class="page-title">Guests</h4>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->
                </div>
                <!--end page-title-box-->
            </div>
            <!--end col-->
        </div>
        <!--end row-->
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <!--end card-header-->
                    <div class="card-body">
                        <form enctype="multipart/form-data" action="includes/grabactions.php" method="POST" >
                            <div class="row mb-3">
                                <div class="col-3">
                                    <p class="mb-0 text-muted">
                                    <div class="form-group">
                                        <label for="useremail">Tag:</label>
                                        <input name="nameField" type="text" class="form-control" required placeholder="Enter tag">
                                    </div>
                                    </p>
                                </div> <!-- end col -->



                                <div class="col-lg-7"></div>

                                <div class="col-lg-2 text-right pt-4">

                                    <button type="submit" class="btn-addRules btn btn-md btn-outline-success">Add rule</button>

                                </div>

                            </div>
                        </form>
                        <table class="table  dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th style="width: 180px;">Tag</th>
                                <th>Link</th>
                                <th style="width: 120px;" class="text-center">Actions</th>
                            </tr>
                            </thead>


                            <tbody id="rows">
                            <?php
                            $guests = R::findAll('guest');
                            foreach ($guests as $guest) {
                                echo '<tr id = ' . $guest["id"] . '>' .
                                    '<td>' . $guest["tag"] . '</td>' .
                                    '<td>http://' . $GLOBALS['domain'] . '/guest/guest.php?key=' . $guest["link_key"] . '</td>' .
                                    '<td><button type="submit" class="btn btn_deleteGuest btn-sm btn-block btn-outline-info">Delete</button></td>' .
                                    '</div>' .
                                    '</td>' .
                                    '</tr>';
                            }
                            ?>
                            </tbody>
                        </table>

                    </div>
                </div>

            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

    <?php
    include("./footer.php");



    ?>
    <!--end footer-->
</div>
<!-- end page content -->
</div>
<!-- end page-wrapper -->




<!-- jQuery  -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/metismenu.min.js"></script>
<script src="assets/js/waves.js"></script>
<script src="assets/js/feather.min.js"></script>
<script src="assets/js/simplebar.min.js"></script>
<script src="assets/js/moment.js"></script>

<!-- Plugins js -->
<script src="assets/js/select2.min.js"></script>

<script src="assets/js/jquery.forms-advanced.js"></script>

<!-- App js -->
<script src="assets/js/app.js"></script>

<!-- Page js -->
<script src="includes/grabactions.js"></script>

</body>

</html>