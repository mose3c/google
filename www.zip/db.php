<?php

$dbname = "mars"; 							//Database name
$dbuser = "mars";							//Database login
$dbpwd 	= "password";							//Database password
$GLOBALS['logspath']     = "logs";		    //Logs folder
$GLOBALS['domain']       = "example.com";		//Domain name for loader
$GLOBALS['panel_folder'] = "panel";			//Panel folder
$GLOBALS['pwd_file'] = "5qDlPuVKoR";	



//Database connect
require_once $GLOBALS['panel_folder'].'/includes/rb.php';
R::setup( 'mysql:host=localhost;dbname='.$dbname, $dbuser, $dbpwd );
session_start();

?>